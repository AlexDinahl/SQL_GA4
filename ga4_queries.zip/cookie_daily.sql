/*
Title:
        BQ - GA4 - ISG - Cookie

Author:
        Dominik Reiner - dominik.reiner@internetstores.com

Description Short:
        Get daily cookie data.
        Refer here for more information: https://miro.com/app/board/uXjVPNluCVQ=/?share_link_id=244039495122

Query Params:
        schema_name: str
        table_name: str
        date_partition: str

Description Long:
        The pseudonymous id (e.g., app instance ID) for the user is the cookie id.
        Each time a user with a certain client opens our app a cookie is created (opt-in).
        The user keeps the id from the cookie as long as it is not deleted.
        When the user opens our app using a different client he will get a different cookie id.
*/
WITH
        cookie as (
                /*
                */
                SELECT
                        user_pseudo_id as cookie_id -- id of cookie when user was first seen
                        , event_date -- date of daily load
                FROM
                        `{source_schema}.{source_table}*`
                WHERE
                        _table_suffix = {date_partition}
                        and starts_with(user_pseudo_id, 'function') is FALSE
                        and starts_with(user_pseudo_id, 'GA') is FALSE
                GROUP BY
                        user_pseudo_id
                        , event_date
        )

SELECT
        {source_shop} as shop
        , c.cookie_id
        , c.event_date
FROM
        cookie as c
