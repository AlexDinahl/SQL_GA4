/*
Title:
        BQ - GA4 - ISG - External Click

Author:
        Dominik Reiner - dominik.reiner@internetstores.com

Description Short:
        Get daily external click in data.
        Refer here for more information: https://miro.com/app/board/uXjVPNluCVQ=/?share_link_id=244039495122

Query Params:
        schema_name: str
        table_name: str
        date_partition: str

Description Long:

*/
WITH
        session_event_source AS (
                SELECT
                        cookie_id
                        , session_id
                        , event_timestamp
                        , event_date
                        , is_first_event
                        -- if source data is available create struct with traffic source
                        , if (
                                source is not null
                                or medium is not null
                                or campaign is not null
                                or gclid is not null
                                , (
                                        select as struct
                                                -- if gclid is not null set google / cpc as traffic source
                                                if(gclid is not null and source is null, 'google', source) as source
                                                , if(gclid is not null and medium is null, 'cpc', medium) as medium
                                                , channel_detail
                                                , campaign
                                                , gclid
                                )
                                , null
                        ) as traffic
                FROM (
                        SELECT
                                user_pseudo_id AS cookie_id
                                , (SELECT e.value.int_value FROM UNNEST(event_params) AS e WHERE e.key = 'ga_session_id') AS session_id
                                , event_timestamp
                                , event_date -- date of daily load
                                -- flag the session's first event
                                , IF (
                                        row_number() OVER (PARTITION BY concat(user_pseudo_id, (SELECT value.int_value FROM unnest(event_params) WHERE key = 'ga_session_id')) ORDER BY event_timestamp ASC) = 1
                                        , true
                                        , false
                                ) as is_first_event
                                -- traffic source information for event
                                , (SELECT value.string_value FROM unnest(event_params) WHERE key = 'source') as source
                                , (SELECT value.string_value FROM unnest(event_params) WHERE key = 'medium') as medium
                                , (SELECT value.string_value FROM unnest(event_params) WHERE key = 'channel_detail') as channel_detail
                                , (SELECT value.string_value FROM unnest(event_params) WHERE key = 'campaign')  as campaign
                                , (SELECT value.string_value FROM unnest(event_params) WHERE key = 'gclid') as gclid
                        FROM
                                `{source_schema}.{source_table}*`
                        WHERE
                                event_name not in ('session_start', 'first_visit')
                                AND _table_suffix = {date_partition}
                                AND starts_with(user_pseudo_id, 'function') is FALSE
                                AND starts_with(user_pseudo_id, 'GA') is FALSE
                                AND _table_suffix < '20230605'
                )
        )
        , session_click_in AS (
                SELECT
                        cookie_id
                        , session_id
                        , event_date
                        , traffic.source
                        , traffic.medium
                        , traffic.channel_detail
                        , traffic.campaign
                        , traffic.gclid
                        , MIN(event_timestamp) AS click_in_timestamp
                FROM
                        session_event_source
                WHERE
                        -- either the event has a source or if not it is the first event
                        (traffic is not null OR traffic is null AND is_first_event = true)
                GROUP BY
                        cookie_id
                        , session_id
                        , event_date
                        , traffic.source
                        , traffic.medium
                        , traffic.channel_detail
                        , traffic.campaign
                        , traffic.gclid
        )
        , session_event_source_new AS (
                /*
                As of 2023-06-05 the traffic source information for each event is available in the export schema.
                No need to revert to utms in event_params anymore.
                */
                SELECT
                        cookie_id
                        , session_id
                        , event_timestamp
                        , event_date
                        , is_first_event
                        -- if source data is available create struct with traffic source
                        , if (
                                source is not null
                                or medium is not null
                                or campaign is not null
                                or gclid is not null
                                , (
                                        select as struct
                                                -- if gclid is not null set google / cpc as traffic source
                                                if(gclid is not null and source is null, 'google', source) as source
                                                , if(gclid is not null and medium is null, 'cpc', medium) as medium
                                                , channel_detail
                                                , campaign
                                                , gclid
                                )
                                , null
                        ) as traffic
                FROM (
                        SELECT
                                user_pseudo_id AS cookie_id
                                , (SELECT e.value.int_value FROM UNNEST(event_params) AS e WHERE e.key = 'ga_session_id') AS session_id
                                , event_timestamp
                                , event_date -- date of daily load
                                -- flag the session's first event
                                , IF (
                                        row_number() OVER (PARTITION BY concat(user_pseudo_id, (SELECT value.int_value FROM unnest(event_params) WHERE key = 'ga_session_id')) ORDER BY event_timestamp ASC) = 1
                                        , true
                                        , false
                                ) as is_first_event
                                -- traffic source information for event
                                , collected_traffic_source.manual_source as source
                                , collected_traffic_source.manual_medium as medium
                                , (SELECT value.string_value FROM unnest(event_params) WHERE key = 'channel_detail') as channel_detail
                                , collected_traffic_source.manual_campaign_name  as campaign
                                , collected_traffic_source.gclid as gclid
                        FROM
                                `{source_schema}.{source_table}*`
                        WHERE
                                event_name not in ('session_start', 'first_visit')
                                AND _table_suffix = {date_partition}
                                AND starts_with(user_pseudo_id, 'function') is FALSE
                                AND starts_with(user_pseudo_id, 'GA') is FALSE
                                AND _table_suffix >= '20230605'
                )
        )
        , session_click_in_new AS (
                SELECT
                        cookie_id
                        , session_id
                        , event_date
                        , traffic.source
                        , traffic.medium
                        , traffic.channel_detail
                        , traffic.campaign
                        , traffic.gclid
                        , MIN(event_timestamp) AS click_in_timestamp
                FROM
                        session_event_source_new
                WHERE
                        -- either the event has a source or if not it is the first event
                        (traffic is not null OR traffic is null AND is_first_event = true)
                GROUP BY
                        cookie_id
                        , session_id
                        , event_date
                        , traffic.source
                        , traffic.medium
                        , traffic.channel_detail
                        , traffic.campaign
                        , traffic.gclid
        )

SELECT
        {source_shop} as shop
        , GENERATE_UUID() as external_click_id
        , session_id
        , source
        , medium
        -- channel grouping
        , CASE
                WHEN medium = 'organic' then 'ORGANIC'
                WHEN medium is null then 'DIRECT'
                WHEN medium = 'cpc' and IFNULL(channel_detail,'') != 'rmkt' then 'SEA'
                WHEN medium = 'psm' or source = 'mydealz' then 'PCM'
                WHEN medium = 'social' then 'SOCIAL_PAID'
                WHEN medium = 'post' or (medium = 'referral' and source = 'facebook') then 'SOCIAL'
                WHEN medium = 'display' or medium = 'video' then 'DISPLAY'
                WHEN medium = 'email' or (medium = 'referral' and REGEXP_CONTAINS(source, r'(.*mail\.|.*deref\-)')) then 'CRM'
                WHEN medium = 'rmkt' or (medium = 'cpc' and channel_detail = 'rmkt') then 'REMARKETING'
                WHEN medium = 'coop' then 'COOPERATION'
                WHEN medium = 'referral' then 'REFERRAL'
                WHEN medium = 'affiliate' then 'AFFILIATE'
                ELSE 'OTHER' -- minor channels that see little traffic
        END as channel
        , channel_detail
        , campaign
        , EXTRACT(DATETIME FROM TIMESTAMP_MICROS(external_click_timestamp) AT TIME ZONE {source_timezone}) AS external_click_timestamp -- time in UTC converted to local time
        , event_date
FROM (
        SELECT
                CONCAT(cookie_id, session_id) AS session_id
                , LOWER(source) as source
                , LOWER(medium) as medium
                , LOWER(channel_detail) as channel_detail
                , campaign
                , click_in_timestamp as external_click_timestamp
                , event_date
        FROM
                session_click_in

        UNION ALL

        SELECT
                CONCAT(cookie_id, session_id) AS session_id
                , LOWER(source) as source
                , LOWER(medium) as medium
                , LOWER(channel_detail) as channel_detail
                , campaign
                , click_in_timestamp as external_click_timestamp
                , event_date
        FROM
                session_click_in_new
)
