/*
Title:
        BQ - GA4 - ISG - Session

Author:
        Dominik Reiner - dominik.reiner@internetstores.com

Description Short:
        Get daily session data.
        Refer here for more information: https://miro.com/app/board/uXjVPNluCVQ=/?share_link_id=244039495122

Query Params:
        schema_name: str
        table_name: str
        date_partition: str

Description Long:
        A session initiates when a user either:
                - Opens our app in the foreground
                - Views a page or screen and no session is currently active (e.g. their previous session has timed out)
        By default, a session ends (times out) after 30 minutes of user inactivity.
        There is no limit to how long a session can last.
*/
WITH
        session AS (
                /*
                When a session starts a session_start event is collected and ga_session_id is generated.
                https://support.google.com/analytics/answer/9191807
                */
                SELECT
                        user_pseudo_id AS cookie_id -- id of cookie when user was first seen
                        , event_params.value.int_value AS session_id -- epoch timestamp of event in seconds, not unique unless concatenated with cookie_id
                        , MIN(
                                EXTRACT(DATETIME FROM TIMESTAMP_MICROS(event_timestamp) AT TIME ZONE {source_timezone}) -- time in UTC converted to local time
                        ) AS session_start_timestamp
                        , event_date -- date of daily load
                FROM
                        `{source_schema}.{source_table}*`
                        , UNNEST(event_params) AS event_params
                WHERE
                        event_params.key = 'ga_session_id'
                        AND _table_suffix = {date_partition}
                        AND starts_with(user_pseudo_id, 'function') is FALSE
                        AND starts_with(user_pseudo_id, 'GA') is FALSE
                GROUP BY
                        user_pseudo_id
                        , event_params.value.int_value
                        , event_date
        )

SELECT
        {source_shop} as shop
        , s.cookie_id
        , CONCAT(s.cookie_id, s.session_id) AS session_id
        , s.session_start_timestamp as session_timestamp
        , s.event_date
FROM
        session AS s
