/*
Title:
        BQ - GA4 - ISG - Transaction

Author:
        Dominik Reiner - dominik.reiner@internetstores.com

Description Short:
        Get daily transaction data.
        Refer here for more information: https://miro.com/app/board/uXjVPNluCVQ=/?share_link_id=244039495122

Query Params:
        schema_name: str
        table_name: str
        date_partition: str

Description Long:

*/
WITH
        transaction AS (
                /*
                */
                SELECT
                        user_pseudo_id AS cookie_id
                        , (SELECT e.value.int_value FROM UNNEST(event_params) AS e WHERE e.key = 'ga_session_id') as session_id
                        , (SELECT e.value.string_value FROM UNNEST(event_params) AS e WHERE e.key = 'transaction_id') as order_number
                        , MIN(EXTRACT(DATETIME FROM TIMESTAMP_MICROS(event_timestamp) AT TIME ZONE {source_timezone})) AS order_timestamp -- time in UTC converted to local time
                        , event_date -- date of daily load
                FROM
                        `{source_schema}.{source_table}*`
                WHERE
                        event_name = 'purchase'
                        AND _table_suffix = {date_partition}
                        and starts_with(user_pseudo_id, 'function') is FALSE
                        and starts_with(user_pseudo_id, 'GA') is FALSE
                GROUP BY
                        user_pseudo_id
                        , 2 -- session_id
                        , 3 -- order_number
                        , event_date
        )

SELECT
        {source_shop} as shop
        , CONCAT(cookie_id, session_id) AS session_id
        , order_number as transaction_id
        , order_timestamp as transaction_timestamp
        , event_date
FROM
        transaction
