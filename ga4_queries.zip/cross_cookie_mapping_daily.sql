/*
Title:
        BQ - GA4 - ISG - Cross Cookie Mapping

Author:
        Dominik Reiner - dominik.reiner@internetstores.com

Description Short:
        Get daily cross cookie mapping data.
        Refer here for more information: https://miro.com/app/board/uXjVPNluCVQ=/?share_link_id=244039495122

Query Params:
        schema_name: str
        table_name: str
        date_partition: str

Description Long:
        The pseudonymous id (e.g., app instance ID) for the user is the cookie id.
        Each time a user with a certain client opens our app a cookie is created (opt-in).
        The user keeps the id from the cookie as long as it is not deleted.
        When the user opens our app using a different client he will get a different cookie id.
        If the user logs into our app we log his login details as well.
        This allows us to map different cookie ids together.
*/
WITH
        login as (
                /*
                There can be multiple crm ids per cookie
                */
                SELECT
                        user_pseudo_id as cookie_id -- id of cookie when user was first seen
                        , event_params.value.string_value as login_id
                        , MIN(
                                EXTRACT(DATETIME FROM TIMESTAMP_MICROS(event_timestamp) AT TIME ZONE {source_timezone}) -- time in UTC converted to local time
                        ) AS mapping_timestamp
                        , event_date
                FROM
                        `{source_schema}.{source_table}*`
                        , UNNEST(event_params) as event_params
                WHERE
                        _table_suffix = {date_partition}
                        AND event_params.key = 'crm_id'
                        AND starts_with(user_pseudo_id, 'function') is FALSE
                        AND starts_with(user_pseudo_id, 'GA') is FALSE
                GROUP BY
                        user_pseudo_id
                        , event_params.value.string_value
                        , event_date
        )

SELECT
        {source_shop} as shop
        , cookie_id
        , login_id
        , mapping_timestamp
        , event_date
FROM
        login
